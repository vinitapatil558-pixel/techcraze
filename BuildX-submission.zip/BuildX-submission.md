# SortSmart — BuildX submission

## Problem statement

In many city neighborhoods, waste is placed in overflowing or shared bins, and wet food waste gets mixed with dry recyclable materials. Once mixed or contaminated, useful materials can be harder to recover, while residents and waste handlers have little guidance at the moment they throw something away.

## Target user

Residents of apartment communities and neighborhoods who want to sort household waste correctly, especially people who are unsure which bin an item belongs in. A secondary user is the building or community waste manager who wants cleaner separated waste.

## Solution hypothesis

If residents get a quick, understandable wet-or-dry sorting suggestion at the point of disposal, they will be more likely to separate household waste correctly. Cleaner separation can make organic waste collection and dry-material recycling easier for the community.

## Core user loop

1. A resident has an item to throw away.
2. They check the SortSmart demo and choose the item.
3. The demo suggests wet or dry and shows the intended bin and a handling tip.
4. The resident places the item in the appropriate bin.
5. The community collects separated waste for suitable composting or recycling.

## MVP / product link

**MVP:** SortSmart is a small interactive web prototype. A user selects one of six sample items and sees its suggested category, bin, and tip. It tests whether a simple sorting prompt is understandable and useful.

**Open the prototype:** [SortSmart web demo](./index.html)

**Scope honesty:** This first prototype is a clickable item-selection demo. It does not use a camera, AI, sensors, or a physical sorting mechanism. The long-term vision is a machine that recognizes waste and directs it into separate compartments.

## MVP proof / screenshots

Capture two screenshots after opening `index.html` in a browser:

1. The starting screen showing the item choices and instruction.
2. The result after selecting “Banana peel” (wet) or “Plastic bottle” (dry).

Use your computer's screenshot shortcut and attach both images in the BuildX submission. If the submission accepts a link, include the prototype file or host it on the tool/platform your course accepts. Do not claim that screenshots show camera-based recognition; this MVP is a selectable demo.

## Key learnings

- The original opportunity is not only overflowing bins; mixed waste makes usable material harder to recover.
- The first experience should answer one immediate question: “Which bin does this item go in?”
- Wet/dry examples make the idea easy to understand, but real local waste rules vary and the prototype needs local validation.
- A simple digital demo can test the sorting interaction before investing in a physical machine.
- Next, I would test the prototype with 5–10 residents, note confusing items, and update the examples and instructions. After that, I would explore a camera-assisted prototype and validate its accuracy before building a mechanism.

## Public pitch — Instagram carousel (7 panels)

Publish these as a carousel. Add a final caption that links to your public MVP if the platform you use supports links in the profile or post. Use the actual public post link in your assignment.

**Panel 1 — The problem**  
Overflowing bins are visible. Mixed waste is a quieter problem: food scraps and recyclable materials often end up together.

**Panel 2 — Why it matters**  
When wet and dry waste are mixed, useful materials can become harder to recover. Residents also have to guess where each item belongs
**Panel 3 — Who I’m designing for**  
Residents in apartment communities who want to sort household waste but need a quick, clear answer.

**Panel 4 — The idea**  
SortSmart: a future smart machine that identifies wet and dry waste, separates it, and supports better recycling and organic waste handling.

**Panel 5 — My MVP**  
I made a simple web demo. Choose a sample item and it suggests a wet or dry bin with a practical tip.

**Panel 6 — What I learned**  
Start with one moment: helping someone decide which bin to use. Test that experience before building a complex machine
**Panel 7 — What’s next**  
I’ll test the demo with residents, improve confusing examples, and then explore camera-assisted recognition. The current demo uses sample choices; it does not yet identify objects automatically.

**Caption:**  
I’m working on SortSmart for BuildX: a way to make household waste sorting easier. The long-term idea is a machine that identifies wet and dry waste and separates it. My first MVP is a small web demo that lets people choose a sample item and see a suggested bin. I want to test whether this simple prompt helps residents sort with more confidence. What item do you find hardest to sort? ♻️

**Public link to add after posting:** `[paste your public Instagram carousel URL here]`

## 2–4 minute video alternative

If you choose YouTube instead, use the carousel text as your outline. Show the prototype on screen and demonstrate one wet item and one dry item. Say plainly that the current version is a selectable sample demo, and explain that automatic camera recognition and physical separation are future steps. Set the video to Public or Unlisted if your assignment accepts Unlisted, then paste its actual URL in the assignment.
